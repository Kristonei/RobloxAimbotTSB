# Roblox Aimbot Script Usage Instructions

## Overview

This custom Roblox aimbot script provides enhanced combat mechanics with the following key features:
- Xbox-like aimbot targeting system
- Behind-player positioning to avoid blocks
- No delay blocking mechanism
- Ping compensation for network latency

## Installation

1. You will need a Lua script executor for Roblox (such as Synapse X, KRNL, or similar)
2. Copy the entire script from `aimbot_script.lua`
3. Paste it into your executor
4. Execute the script while in a Roblox game

## Default Controls

- **Right Mouse Button (MouseButton2)**: Activate aimbot targeting
- **Q Key**: Dash to position behind current target
- **E Key**: Execute instant block (no delay)

## Configuration

The script includes a configuration section at the top that you can modify to suit your preferences:

```lua
getgenv().AimbotConfig = {
    Enabled = true,                 -- Master toggle for the entire script
    TeamCheck = false,              -- Set to true to only target enemy team members
    TargetPart = "HumanoidRootPart", -- Body part to target
    TriggerKey = "MouseButton2",    -- Key to activate aimbot (right mouse button)
    DashKey = "Q",                  -- Key to dash behind target
    BlockKey = "E",                 -- Key for instant blocking
    Sensitivity = 0.1,              -- Aim smoothness (lower = smoother)
    BehindPlayerDistance = 3,       -- Distance to position behind target
    PingCompensation = true,        -- Enable ping-based position prediction
    BlockDetection = true,          -- Enable obstacle detection
    DebugMode = false,              -- Enable visualization and logging
    FOVSettings = {
        Enabled = true,             -- Enable FOV targeting restriction
        Visible = true,             -- Show FOV circle on screen
        Radius = 90,                -- FOV circle size
        Color = Color3.fromRGB(255, 255, 255), -- FOV circle color
        Transparency = 0.5,         -- FOV circle transparency
        Sides = 60,                 -- FOV circle quality
        Thickness = 1               -- FOV circle line thickness
    }
}
```

## Feature Details

### Behind-Player Positioning
- When you press the dash key (default: Q), the script calculates a position behind your current target
- The script uses raycasting to detect obstacles and will find alternative positions if the direct path is blocked
- A small height offset is added for better visibility

### No Block Delay
- The block key (default: E) triggers an immediate block with no animation delay
- The script attempts multiple methods to ensure blocking works across different games

### Ping Compensation
- The script measures your network latency and adjusts targeting accordingly
- Target positions are predicted based on their velocity and your ping
- This creates a more consistent experience regardless of connection quality

## Troubleshooting

If the script doesn't work as expected:

1. **Verify executor compatibility**: The script requires an executor that supports Drawing library and other modern functions
2. **Check for errors in console**: Enable DebugMode to see more detailed information
3. **Game compatibility**: This script works best with games that use standard Roblox character models
4. **Adjust settings**: Try modifying sensitivity and FOV settings if targeting feels off

## Advanced Usage

- Set `DebugMode = true` to visualize behind-player positions with a red marker
- Adjust `BehindPlayerDistance` to control how far behind targets you position
- Modify `Sensitivity` to change how quickly the aimbot locks onto targets
- Customize FOV settings to control targeting range and visual appearance
