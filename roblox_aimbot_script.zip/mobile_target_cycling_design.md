# Mobile Target Cycling Feature - Research and Design

## Mobile-Specific Considerations

1. **Touch Interface Requirements**
   - Mobile devices lack keyboard and mouse inputs
   - Touch controls must be intuitive and accessible
   - UI elements need to be large enough for finger tapping
   - Must avoid cluttering the screen with too many controls

2. **Roblox Mobile Input Methods**
   - Mobile devices use TouchEnabled events instead of MouseButton events
   - Need to create custom UI buttons for target cycling
   - Can leverage Roblox's Mobile GUI framework
   - Must consider different screen sizes and orientations

## Target Cycling Design

### UI Component
```lua
-- Create a target cycling button for mobile
local targetCycleButton = Instance.new("TextButton")
targetCycleButton.Size = UDim2.new(0, 60, 0, 60) -- Large enough for finger tapping
targetCycleButton.Position = UDim2.new(0.9, -30, 0.7, -30) -- Bottom right area
targetCycleButton.Text = "Cycle"
targetCycleButton.BackgroundTransparency = 0.5
targetCycleButton.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
targetCycleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
targetCycleButton.BorderSizePixel = 2
targetCycleButton.BorderColor3 = Color3.fromRGB(255, 255, 255)
targetCycleButton.Parent = -- Player GUI
```

### Target Selection Logic
```lua
-- Array to store potential targets
local potentialTargets = {}

-- Function to refresh potential targets list
local function refreshTargetList()
    potentialTargets = {}
    for _, player in ipairs(Players:GetPlayers()) do
        if isValidTarget(player) and isWithinFOV(player) then
            table.insert(potentialTargets, player)
        end
    end
    
    -- Sort by distance
    table.sort(potentialTargets, function(a, b)
        local distA = (a.Character.HumanoidRootPart.Position - LocalPlayer.Character.HumanoidRootPart.Position).Magnitude
        local distB = (b.Character.HumanoidRootPart.Position - LocalPlayer.Character.HumanoidRootPart.Position).Magnitude
        return distA < distB
    end)
end

-- Current target index
local currentTargetIndex = 1

-- Function to cycle to next target
local function cycleToNextTarget()
    refreshTargetList()
    
    if #potentialTargets == 0 then
        SelectedTarget = nil
        return
    end
    
    currentTargetIndex = currentTargetIndex % #potentialTargets + 1
    SelectedTarget = potentialTargets[currentTargetIndex]
    
    -- Visual feedback for target change
    showTargetIndicator(SelectedTarget)
end
```

### Visual Indicators
```lua
-- Create visual indicator for current target
local function createTargetIndicator()
    local indicator = Instance.new("BillboardGui")
    indicator.Name = "TargetIndicator"
    indicator.Size = UDim2.new(0, 40, 0, 40)
    indicator.AlwaysOnTop = true
    indicator.Adornee = nil -- Will be set when target changes
    
    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(1, 0, 1, 0)
    frame.BackgroundTransparency = 0.5
    frame.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
    frame.BorderSizePixel = 0
    frame.Parent = indicator
    
    indicator.Parent = game.CoreGui
    
    return indicator
end

local targetIndicator = createTargetIndicator()

-- Update indicator position
local function showTargetIndicator(target)
    if not target or not target.Character or not target.Character:FindFirstChild("Head") then
        targetIndicator.Adornee = nil
        targetIndicator.Enabled = false
        return
    end
    
    targetIndicator.Adornee = target.Character.Head
    targetIndicator.Enabled = true
end
```

## Integration with Existing Script

### Configuration Updates
```lua
getgenv().AimbotConfig = {
    -- Existing settings...
    
    -- Mobile-specific settings
    MobileControls = true,
    TargetCycleButtonPosition = UDim2.new(0.9, -30, 0.7, -30),
    TargetIndicatorEnabled = true,
    TargetIndicatorColor = Color3.fromRGB(255, 0, 0),
    AutoTargetClosest = true -- Automatically target closest player
}
```

### Mobile Detection
```lua
-- Detect if user is on mobile
local UserInputService = game:GetService("UserInputService")
local isMobile = UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled

-- Apply mobile-specific settings if on mobile
if isMobile then
    setupMobileControls()
end
```

## Performance Considerations

1. **Optimization for Mobile**
   - Mobile devices typically have less processing power
   - Need to limit frequency of target list refreshes
   - Visual indicators should be simple to render
   - Consider battery usage impact

2. **Throttling**
   - Implement cooldown for target cycling (e.g., 0.5 seconds)
   - Refresh target list only when needed, not continuously
   - Use RunService.Heartbeat instead of RenderStepped for less intensive operations

## User Experience Improvements

1. **Feedback Mechanisms**
   - Visual highlight around current target
   - Optional sound effect when cycling targets
   - Haptic feedback if available
   - Text indicator showing current target name/distance

2. **Accessibility**
   - Configurable button size and position
   - Option for auto-targeting without manual cycling
   - Color options for colorblind users
