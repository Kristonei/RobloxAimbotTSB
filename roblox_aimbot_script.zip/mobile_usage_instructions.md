# Mobile Aimbot Usage Instructions

## Overview

This updated Roblox aimbot script is specifically optimized for mobile devices, with touch-friendly controls and a target cycling feature to handle multiple nearby players. Key features include:

- Xbox-like aimbot targeting system
- Behind-player positioning to avoid blocks
- No delay blocking mechanism
- Ping compensation for network latency
- **NEW: Mobile touch controls with target cycling**

## Installation

1. You will need a Lua script executor for Roblox that works on mobile (such as Arceus X, Hydrogen, or similar)
2. Copy the entire script from `aimbot_script_mobile.lua`
3. Paste it into your executor
4. Execute the script while in a Roblox game

## Mobile Controls

The script automatically detects if you're on mobile and creates four touch buttons:

1. **Aim Button**: Press and hold to activate aimbot targeting
2. **Cycle Button**: Tap to switch between targets when multiple players are nearby
3. **Dash Button**: Tap to dash behind your current target
4. **Block Button**: Tap to execute instant block (no delay)

All buttons are positioned in the bottom-right area of the screen for easy access.

## Target Cycling Feature

The new target cycling system allows you to handle multiple nearby players:

- By default, the closest player in your FOV is automatically targeted
- Tap the "Cycle" button to switch to the next closest player
- A red indicator appears above the currently selected target
- The target's name is displayed above the indicator

This feature ensures you can quickly switch between multiple opponents in combat situations.

## Configuration

The script includes mobile-specific configuration options at the top:

```lua
-- Mobile-specific settings
MobileControls = true,
TargetCycleButtonPosition = UDim2.new(0.9, -30, 0.7, -30),
TargetIndicatorEnabled = true,
TargetIndicatorColor = Color3.fromRGB(255, 0, 0),
AutoTargetClosest = true, -- Automatically target closest player
TargetCycleButtonSize = UDim2.new(0, 60, 0, 60)
```

You can adjust these settings to customize the mobile experience:
- Change button positions and sizes
- Modify the target indicator color
- Enable/disable automatic targeting of the closest player

## Troubleshooting for Mobile

If the script doesn't work as expected on mobile:

1. **Check executor compatibility**: Make sure your mobile executor supports all required functions
2. **UI visibility issues**: If buttons are hard to see, adjust their position and size in the configuration
3. **Performance problems**: If you experience lag, try disabling FOV circle or target indicator
4. **Button responsiveness**: If buttons aren't responding, try increasing their size in the configuration

## Advanced Mobile Usage

- The target cycling has a 0.5-second cooldown to prevent accidental spam
- Target list is automatically refreshed every 2 seconds to detect new players
- Visual feedback is provided when buttons are pressed
- The script automatically detects mobile devices and adapts accordingly
